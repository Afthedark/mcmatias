# Frontend - MultiCentro Matías

Frontend escalable y mantenible con **Vanilla JavaScript**, **HTML5**, **Bootstrap 5** (CDN), **Axios** y **CSS modular**. Arquitectura MPA (Multi-Page Application) inspirada en AdminLTE.

## 📁 Estructura de Carpetas

```
frontend/
├── html/                          # Páginas HTML
│   ├── index.html                 # Landing page
│   ├── login.html                 # Página de login
│   ├── dashboard.html             # Panel principal
│   └── layouts/                   # Componentes reutilizables
│       ├── navbar.html            # Barra de navegación
│       ├── sidebar.html           # Menú lateral
│       └── footer.html            # Pie de página
├── css/                           # Estilos
│   ├── login.css                  # Estilos de login
│   └── dashboard.css              # Estilos del dashboard
├── js/                            # JavaScript modular
│   ├── core/                      # Módulos centrales
│   │   ├── authService.js         # Servicio de autenticación (JWT)
│   │   ├── apiClient.js           # Cliente HTTP (Fetch API)
│   │   └── componentInjector.js   # Inyección dinámica de componentes
│   ├── pages/                     # Lógica por página
│   │   ├── login.js               # Lógica de login
│   │   └── dashboard.js           # Lógica del dashboard
│   ├── components/                # Componentes reutilizables
│   │   └── (pronto)
│   └── utils/                     # Funciones utilitarias
│       └── utils.js               # Helpers y validaciones
└── assets/                        # Recursos estáticos
    ├── icons/                     # Iconos personalizados
    └── images/                    # Imágenes
```

---

## 🎯 Características Principales

### ✅ Autenticación JWT
- Login seguro con JWT
- Almacenamiento de token en localStorage
- Recuperación automática de sesión
- Logout con limpeza de datos
- Validación de expiración de token

### ✅ Sistema Modular y Escalable
- **Servicios centrales** (`core/`) compartidos en toda la aplicación
- **Páginas independientes** con su propio HTML + JS
- **Componentes reutilizables** (navbar, sidebar, footer)
- **Utilities compartidas** para validaciones y formateo

### ✅ Componentes Dinámicos
- Inyección de navbar, sidebar y footer en cualquier página
- Actualización automática de datos de usuario
- Menú responsivo para móvil

### ✅ Diseño AdminLTE
- Interfaz moderna e intuitiva
- Totalmente responsivo (mobile-first)
- Animaciones suaves
- Bootstrap 5 via CDN (sin dependencias npm)

---

## 🚀 Guía de Inicio Rápido

### 1. Asegurate que el backend esté corriendo
```bash
npm run dev
# El servidor estará en http://localhost:3000
```

### 2. Acceder al frontend
- **Landing page:** http://localhost:3000/
- **Login:** http://localhost:3000/html/login.html
- **Dashboard:** http://localhost:3000/html/dashboard.html (requiere estar autenticado)

### 3. Credenciales de prueba
- **Email:** `admin@multicentromatias.com`
- **Contraseña:** `admin123`

---

## 📚 Módulos Core

### 1. **authService.js** - Servicio de Autenticación

Maneja toda la lógica de autenticación y sesión.

```javascript
// Login
await authService.login(email, password);

// Logout
authService.logout();

// Obtener usuario actual
const user = authService.getUser();

// Obtener token
const token = authService.getToken();

// Verificar si está autenticado
if (authService.isAuthenticated()) { ... }

// Verificar si token es válido
if (authService.isTokenValid()) { ... }

// Obtener rol y nombre
const role = authService.getUserRole();
const name = authService.getUserName();
```

### 2. **apiClient.js** - Cliente HTTP

Wrapper sobre Fetch API con manejo automático de JWT.

```javascript
// GET
const data = await apiClient.get('/productos');

// POST
const response = await apiClient.post('/productos', { nombre: '...' });

// PUT
await apiClient.put('/productos/1', { nombre: '...' });

// DELETE
await apiClient.delete('/productos/1');

// Manejo automático de errores y 401 (sesión expirada)
```

### 3. **componentInjector.js** - Inyección de Componentes

Carga dinámicamente componentes HTML compartidos.

```javascript
// Inyectar un componente
await componentInjector.injectComponent('navbar-container', 'navbar');

// Inyectar múltiples
await componentInjector.injectComponents({
  'navbar-container': 'navbar',
  'sidebar-container': 'sidebar',
  'footer-container': 'footer'
});

// Renderizar navbar con datos del usuario
componentInjector.renderNavbar();

// Marcar un menú como activo en sidebar
componentInjector.renderSidebar('dashboard');
```

---

## 📄 Páginas Existentes

### 1. **index.html** - Landing Page
- Página de bienvenida
- Botón para acceder a login
- Información básica del sistema

### 2. **login.html** - Autenticación
- Formulario de login
- Toggle mostrar/ocultar contraseña
- Recordar credenciales
- Mensajes de error
- Redirección automática al dashboard si ya está autenticado

### 3. **dashboard.html** - Panel Principal
- Navbar con datos del usuario y logout
- Sidebar con menú reutilizable
- Estadísticas principales (ventas, stock, servicios)
- Últimas transacciones
- Accesos rápidos
- Footer con información del sistema

---

## 🛠️ Cómo Agregar una Nueva Página

### 1. Crear archivo HTML
```html
<!-- frontend/html/productos.html -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Productos - MultiCentro Matías</title>
  
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet" />
  
  <!-- Custom CSS -->
  <link rel="stylesheet" href="/css/productos.css" />
</head>

<body>
  <!-- Contenedores para componentes dinámicos -->
  <div id="navbar-container"></div>
  <div id="sidebar-container"></div>
  
  <main style="margin-left: 250px; margin-top: 80px;">
    <div class="container-fluid p-4">
      <!-- Contenido de la página -->
      <h1>Productos</h1>
      <div id="contenido"></div>
    </div>
  </main>
  
  <div id="footer-container"></div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="/js/core/authService.js"></script>
  <script src="/js/core/apiClient.js"></script>
  <script src="/js/core/componentInjector.js"></script>
  <script src="/js/utils/utils.js"></script>
  <script src="/js/pages/productos.js"></script>
</body>
</html>
```

### 2. Crear archivo JS de la página
```javascript
// frontend/js/pages/productos.js
document.addEventListener('DOMContentLoaded', async function () {
  // Verificar autenticación
  if (!authService.isAuthenticated()) {
    window.location.href = '/html/login.html';
    return;
  }

  // Inyectar componentes
  await componentInjector.injectComponents({
    'navbar-container': 'navbar',
    'sidebar-container': 'sidebar',
    'footer-container': 'footer'
  });

  // Marcar sidebar activo
  componentInjector.renderSidebar('productos');

  // Cargar datos
  loadProductos();
});

async function loadProductos() {
  try {
    const productos = await apiClient.get('/productos');
    // Renderizar productos
    console.log(productos);
  } catch (error) {
    console.error('Error:', error);
    showToast(error.message, 'danger');
  }
}
```

### 3. Crear estilos (opcional)
```css
/* frontend/css/productos.css */
/* Estilos específicos de la página */
```

### 4. Agregar link en el sidebar
```html
<!-- Editar frontend/html/layouts/sidebar.html -->
<a
  href="/html/productos.html"
  class="nav-link sidebar-link text-dark py-2 px-3 rounded"
  data-page="productos"
>
  <i class="bi bi-box-seam me-2"></i> Productos
</a>
```

---

## 🔐 Seguridad

### JWT en localStorage
El token JWT se almacena en `localStorage` bajo la clave `jwt_token`. Se envía automáticamente en cada request:

```javascript
headers: {
  'Authorization': `Bearer ${token}`
}
```

### Validación de Sesión
- El `authService` verifica si el token es válido
- Si el token expira (401), se limpia la sesión y se redirige a login
- El frontend también decodifica el payload para validar localmente

### Recomendaciones
- **Nunca** hagas login en el frontend
- **Siempre** valida en el servidor
- El frontend solo controla la UI, no la autorización
- El servidor es la fuente de verdad

---

## 📱 Responsividad

El frontend es **100% responsivo**:

- **Mobile (<768px):** Sidebar se oculta, contenido ocupa 100%
- **Tablet (768px-1024px):** Layout adaptativo
- **Desktop (>1024px):** Sidebar fijo de 250px

---

## 🎨 Personalización de Estilos

### Variables CSS globales
Edita los colores en `dashboard.css` y `login.css`:

```css
:root {
  --primary-color: #667eea;
  --secondary-color: #764ba2;
  --light-bg: #f4f6f9;
}
```

---

## 📦 Dependencias Externas

No hay dependencias npm. El proyecto usa:

- **Bootstrap 5** - CSS Framework (CDN)
- **Bootstrap Icons** - Iconos (CDN)
- **Fetch API** - Requests HTTP (nativo)
- **localStorage** - Almacenamiento local (nativo)

---

## 🐛 Troubleshooting

### Error 404 en componentes
- Asegúrate de que los archivos en `layouts/` existan
- Verifica los nombres de archivo en `componentInjector.injectComponent()`

### Token no se envía
- Verifica que `authService.getToken()` devuelve un valor
- Revisa la consola del navegador (F12 → Network)

### Redirección constante a login
- El token puede haber expirado
- Verifica en `Application → localStorage` que `jwt_token` existe

### CSS no carga
- Limpia caché del navegador (Ctrl+Shift+R)
- Verifica rutas en los `<link>` (deben ser `/css/...`)

---

## 📖 Next Steps

1. **Crear páginas adicionales** (productos, ventas, clientes, etc.)
2. **Integrar con API real** usando `apiClient`
3. **Agregar validaciones** usando `utils.js`
4. **Implementar modales y formularios**
5. **Agregar tabla de datos con paginación**
6. **Sistema de notificaciones** con `showToast()`

---

## 📞 Soporte

Para preguntas sobre el frontend, revisa:
- Estructura de carpetas: `frontend/`
- Servicios: `frontend/js/core/`
- Ejemplos de páginas: `frontend/html/dashboard.html`

---

**Versión:** 1.0.0  
**Última actualización:** Enero 2025  
**Backend:** Node.js + Express + Sequelize
