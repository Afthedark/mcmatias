/**
 * authService.js
 * Servicio centralizado para manejo de autenticación y tokens JWT
 * Maneja: Login, Logout, Validación de tokens, Almacenamiento de sesión
 */

class AuthService {
  constructor() {
    this.tokenKey = 'jwt_token';
    this.userKey = 'user_data';
    this.apiUrl = '/api/auth';
  }

  /**
   * Realiza login con email y contraseña
   * @param {string} email - Email del usuario
   * @param {string} password - Contraseña
   * @returns {Promise<Object>} - Datos del usuario y token
   */
  async login(email, password) {
    try {
      const response = await fetch(`${this.apiUrl}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        // Usar nombres de campo que espera el backend
        body: JSON.stringify({ 
          correo_electronico: email, 
          contraseña: password 
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Credenciales inválidas');
      }

      const data = await response.json();
      
      // Guardar token JWT
      if (data.token) {
        this.setToken(data.token);
      }
      
      // Guardar datos del usuario normalizados
      if (data.user) {
        const userData = {
          id_usuario: data.user.id_usuario,
          nombre: data.user.nombre_apellido,
          email: data.user.correo_electronico || email,
          rol: data.user.rol,
          sucursal: data.user.sucursal
        };
        this.setUser(userData);
      }

      return data;
    } catch (error) {
      console.error('Error en login:', error);
      throw error;
    }
  }

  /**
   * Realiza logout y limpia la sesión
   */
  logout() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  /**
   * Obtiene el token JWT almacenado
   * @returns {string|null} - Token o null si no existe
   */
  getToken() {
    return localStorage.getItem(this.tokenKey);
  }

  /**
   * Almacena el token JWT
   * @param {string} token - Token JWT
   */
  setToken(token) {
    localStorage.setItem(this.tokenKey, token);
  }

  /**
   * Obtiene los datos del usuario almacenados
   * @returns {Object|null} - Datos del usuario o null
   */
  getUser() {
    const user = localStorage.getItem(this.userKey);
    return user ? JSON.parse(user) : null;
  }

  /**
   * Almacena los datos del usuario
   * @param {Object} user - Datos del usuario
   */
  setUser(user) {
    localStorage.setItem(this.userKey, JSON.stringify(user));
  }

  /**
   * Verifica si el usuario está autenticado
   * @returns {boolean} - True si hay token válido
   */
  isAuthenticated() {
    return !!this.getToken();
  }

  /**
   * Verifica si un token es válido (sin expiración en cliente)
   * Nota: La validación real se hace en el servidor
   * @returns {boolean}
   */
  isTokenValid() {
    const token = this.getToken();
    if (!token) return false;

    try {
      // Decodifica el payload sin verificar firma (solo para validación básica)
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expirationTime = payload.exp * 1000;
      return Date.now() < expirationTime;
    } catch (error) {
      return false;
    }
  }

  /**
   * Obtiene el rol del usuario actual
   * @returns {string|null} - Rol del usuario
   */
  getUserRole() {
    const user = this.getUser();
    return user ? user.rol : null;
  }

  /**
   * Obtiene el nombre del usuario actual
   * @returns {string|null} - Nombre del usuario
   */
  getUserName() {
    const user = this.getUser();
    return user ? user.nombre : null;
  }
}

// Exportar instancia singleton
const authService = new AuthService();
