/**
 * apiClient.js
 * Cliente HTTP centralizado usando Fetch API
 * Maneja: Headers, autenticación automática, manejo de errores
 */

class ApiClient {
  constructor(baseURL = '/api') {
    this.baseURL = baseURL;
    this.timeout = 10000; // 10 segundos
  }

  /**
   * Genera los headers por defecto incluyendo token JWT
   * @returns {Object} - Headers HTTP
   */
  getHeaders() {
    const headers = {
      'Content-Type': 'application/json'
    };

    // Agregar token JWT si existe
    const token = authService.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    return headers;
  }

  /**
   * Método genérico para hacer requests
   * @param {string} method - GET, POST, PUT, DELETE, etc
   * @param {string} endpoint - Endpoint relativo ej: /productos/1
   * @param {Object} data - Datos a enviar (para POST, PUT)
   * @param {Object} options - Opciones adicionales
   * @returns {Promise<Object>} - Respuesta del servidor
   */
  async request(method, endpoint, data = null, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      method,
      headers: this.getHeaders(),
      ...options
    };

    if (data && (method === 'POST' || method === 'PUT')) {
      // Si es FormData, no incluir Content-Type (el navegador lo hará)
      if (data instanceof FormData) {
        delete config.headers['Content-Type'];
        config.body = data;
      } else {
        config.body = JSON.stringify(data);
      }
    }

    try {
      const response = await Promise.race([
        fetch(url, config),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Timeout')), this.timeout)
        )
      ]);

      // Manejar respuesta 401 (No autorizado)
      if (response.status === 401) {
        authService.logout();
        window.location.href = '/html/login.html';
        throw new Error('Sesión expirada. Por favor, inicia sesión nuevamente.');
      }

      // Manejar respuesta 403 (Prohibido)
      if (response.status === 403) {
        throw new Error('No tienes permiso para realizar esta acción.');
      }

      // Parsear respuesta
      const contentType = response.headers.get('content-type');
      let responseData;

      if (contentType && contentType.includes('application/json')) {
        responseData = await response.json();
      } else {
        responseData = await response.text();
      }

      // Verificar si la respuesta fue exitosa
      if (!response.ok) {
        throw new Error(
          responseData.message ||
          `Error ${response.status}: ${response.statusText}`
        );
      }

      return responseData;
    } catch (error) {
      console.error(`Error en ${method} ${url}:`, error);
      throw error;
    }
  }

  /**
   * GET request
   */
  get(endpoint) {
    return this.request('GET', endpoint);
  }

  /**
   * POST request
   */
  post(endpoint, data) {
    return this.request('POST', endpoint, data);
  }

  /**
   * PUT request
   */
  put(endpoint, data) {
    return this.request('PUT', endpoint, data);
  }

  /**
   * DELETE request
   */
  delete(endpoint) {
    return this.request('DELETE', endpoint);
  }

  /**
   * PATCH request
   */
  patch(endpoint, data) {
    return this.request('PATCH', endpoint, data);
  }
}

// Exportar instancia singleton
const apiClient = new ApiClient();
