/**
 * componentInjector.js
 * Inyecta dinámicamente componentes reutilizables (navbar, sidebar, footer)
 * Permite mantener una única versión de componentes compartidos
 */

class ComponentInjector {
  constructor(basePath = '/html/layouts') {
    this.basePath = basePath;
  }

  /**
   * Carga e inyecta un componente HTML en un elemento del DOM
   * @param {string} elementId - ID del elemento donde inyectar
   * @param {string} componentName - Nombre del componente (sin .html)
   * @returns {Promise<void>}
   */
  async injectComponent(elementId, componentName) {
    try {
      const element = document.getElementById(elementId);
      if (!element) {
        console.warn(`Elemento con ID '${elementId}' no encontrado`);
        return;
      }

      const componentPath = `${this.basePath}/${componentName}.html`;
      const response = await fetch(componentPath);

      if (!response.ok) {
        throw new Error(`No se pudo cargar ${componentName}`);
      }

      const html = await response.text();
      element.innerHTML = html;

      // Ejecutar scripts después de inyectar (si los hay)
      this.executeScripts(element);

      // Disparar evento personalizado
      document.dispatchEvent(
        new CustomEvent('componentInjected', {
          detail: { componentName }
        })
      );
    } catch (error) {
      console.error(`Error inyectando componente ${componentName}:`, error);
    }
  }

  /**
   * Carga e inyecta múltiples componentes
   * @param {Object} components - Objeto {elementId: componentName}
   * @returns {Promise<void>}
   */
  async injectComponents(components) {
    const promises = Object.entries(components).map(([elementId, componentName]) =>
      this.injectComponent(elementId, componentName)
    );
    await Promise.all(promises);
  }

  /**
   * Ejecuta scripts dentro de un elemento inyectado
   * @param {HTMLElement} element - Elemento que contiene scripts
   */
  executeScripts(element) {
    const scripts = element.querySelectorAll('script');
    scripts.forEach((script) => {
      const newScript = document.createElement('script');
      if (script.src) {
        newScript.src = script.src;
      } else {
        newScript.textContent = script.textContent;
      }
      document.body.appendChild(newScript);
    });
  }

  /**
   * Renderiza el navbar con datos del usuario
   * Debe ser llamado después de inyectar el componente navbar
   */
  renderNavbar() {
    const user = authService.getUser();
    if (!user) return;

    const userNameElement = document.getElementById('navbar-user-name');
    const userRoleElement = document.getElementById('navbar-user-role');

    if (userNameElement) {
      userNameElement.textContent = user.nombre || 'Usuario';
    }
    if (userRoleElement) {
      userRoleElement.textContent = user.rol || 'Sin rol';
    }
  }

  /**
   * Renderiza el sidebar activando el enlace actual
   * @param {string} currentPage - Identificador de página actual (ej: 'dashboard', 'productos')
   */
  renderSidebar(currentPage) {
    const sidebarLinks = document.querySelectorAll('.sidebar-link');
    sidebarLinks.forEach((link) => {
      const page = link.getAttribute('data-page');
      if (page === currentPage) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }
}

// Exportar instancia singleton
const componentInjector = new ComponentInjector();
