/**
 * dashboard.js
 * Lógica de la página de Dashboard
 * Maneja: Carga de datos, estadísticas, componentes dinámicos
 */

document.addEventListener('DOMContentLoaded', async function () {
  // Verificar autenticación
  if (!authService.isAuthenticated() || !authService.isTokenValid()) {
    window.location.href = '/html/login.html';
    return;
  }

  // Inyectar componentes reutilizables
  await componentInjector.injectComponents({
    'navbar-container': 'navbar',
    'sidebar-container': 'sidebar',
    'footer-container': 'footer'
  });

  // Marcar sidebar como activo
  setTimeout(() => {
    componentInjector.renderSidebar('dashboard');
  }, 100);

  // Cargar datos del usuario
  loadUserData();

  // Cargar estadísticas
  loadDashboardStats();

  // Cargar últimas ventas
  loadRecentSales();

  // Verificar API
  checkApiStatus();

  // Agregar listeners a botones de acceso rápido
  setupQuickAccessButtons();
});

/**
 * Carga y muestra datos del usuario autenticado
 */
function loadUserData() {
  const user = authService.getUser();
  if (!user) {
    window.location.href = '/html/login.html';
    return;
  }

  document.getElementById('user-name').textContent = user.nombre || 'Usuario';
  document.getElementById('user-role').textContent = user.rol || 'Sin rol';
  document.getElementById('user-sucursal').textContent = user.id_sucursal || '-';

  // Mostrar expiración del token
  const token = authService.getToken();
  if (token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiryDate = new Date(payload.exp * 1000);
      document.getElementById('token-expiry').textContent = expiryDate.toLocaleString('es-ES');
    } catch (error) {
      console.error('Error al parsear token:', error);
    }
  }
}

/**
 * Carga estadísticas principales del dashboard
 */
async function loadDashboardStats() {
  try {
    // Simulación de datos - Reemplazar con llamadas reales a la API
    const stats = {
      ventasHoy: 12,
      stockBajo: 5,
      serviciosPendientes: 3,
      clientesNuevos: 8
    };

    document.getElementById('stat-ventas-hoy').textContent = stats.ventasHoy;
    document.getElementById('stat-stock-bajo').textContent = stats.stockBajo;
    document.getElementById('stat-servicios-pendientes').textContent = stats.serviciosPendientes;
    document.getElementById('stat-clientes-nuevos').textContent = stats.clientesNuevos;

    // Aquí van las llamadas reales a la API:
    // const ventasResponse = await apiClient.get('/ventas');
    // const inventarioResponse = await apiClient.get('/inventario');
    // etc.
  } catch (error) {
    console.error('Error cargando estadísticas:', error);
  }
}

/**
 * Carga las últimas ventas realizadas
 */
async function loadRecentSales() {
  const recentSalesList = document.getElementById('recent-sales-list');

  try {
    // Simulación de datos - Reemplazar con llamada real a la API
    const mockSales = [
      {
        id: 1,
        numero_boleta: 'BOL-001',
        cliente: 'Juan Pérez',
        total: 150.00,
        fecha: new Date().toLocaleDateString('es-ES')
      },
      {
        id: 2,
        numero_boleta: 'BOL-002',
        cliente: 'María García',
        total: 280.50,
        fecha: new Date().toLocaleDateString('es-ES')
      },
      {
        id: 3,
        numero_boleta: 'BOL-003',
        cliente: 'Carlos López',
        total: 95.00,
        fecha: new Date().toLocaleDateString('es-ES')
      }
    ];

    if (mockSales.length === 0) {
      recentSalesList.innerHTML = '<p class="text-muted mb-0">Sin ventas en los últimos 30 días</p>';
      return;
    }

    let html = '<div class="table-responsive"><table class="table table-sm mb-0"><tbody>';

    mockSales.forEach((sale) => {
      html += `
        <tr>
          <td>
            <strong>${sale.numero_boleta}</strong><br>
            <small class="text-muted">${sale.cliente}</small>
          </td>
          <td class="text-end">
            <strong>$${parseFloat(sale.total).toFixed(2)}</strong><br>
            <small class="text-muted">${sale.fecha}</small>
          </td>
          <td class="text-end">
            <a href="#" class="btn btn-sm btn-outline-primary" title="Ver detalles">
              <i class="bi bi-eye"></i>
            </a>
          </td>
        </tr>
      `;
    });

    html += '</tbody></table></div>';
    recentSalesList.innerHTML = html;

    // Aquí va la llamada real a la API:
    // const response = await apiClient.get('/ventas?limit=10&order=DESC');
  } catch (error) {
    console.error('Error cargando ventas:', error);
    recentSalesList.innerHTML = '<p class="text-danger mb-0">Error al cargar ventas</p>';
  }
}

/**
 * Verifica el estado de la API
 */
async function checkApiStatus() {
  const apiStatusElement = document.getElementById('api-status');

  try {
    // Hacer un ping simple a la API
    const response = await fetch('/api/auth/verify', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authService.getToken()}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      apiStatusElement.innerHTML = '<span class="badge bg-success">En línea</span>';
    } else {
      apiStatusElement.innerHTML = '<span class="badge bg-warning">Conectando...</span>';
    }
  } catch (error) {
    console.error('Error verificando API:', error);
    apiStatusElement.innerHTML = '<span class="badge bg-danger">Sin conexión</span>';
  }
}

/**
 * Configura los botones de acceso rápido
 */
function setupQuickAccessButtons() {
  const newSaleBtn = document.getElementById('quick-nueva-venta');
  const newProductBtn = document.getElementById('quick-nuevo-producto');
  const newClientBtn = document.getElementById('quick-nuevo-cliente');
  const newServiceBtn = document.getElementById('quick-nuevo-servicio');

  newSaleBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    // TODO: Redirigir a nueva venta o abrir modal
    alert('Nueva venta - Próximamente');
  });

  newProductBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    // TODO: Redirigir a nuevo producto
    alert('Nuevo producto - Próximamente');
  });

  newClientBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    // TODO: Redirigir a nuevo cliente
    alert('Nuevo cliente - Próximamente');
  });

  newServiceBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    // TODO: Redirigir a nuevo servicio
    alert('Nuevo servicio - Próximamente');
  });
}
