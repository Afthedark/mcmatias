/**
 * login.js
 * Lógica de la página de login
 * Maneja: Validación, autenticación, redirección
 */

document.addEventListener('DOMContentLoaded', function () {
  const loginForm = document.getElementById('loginForm');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const togglePasswordBtn = document.getElementById('togglePassword');
  const rememberMeCheckbox = document.getElementById('rememberMe');
  const errorAlert = document.getElementById('errorAlert');
  const errorMessage = document.getElementById('errorMessage');
  const loginBtn = document.getElementById('loginBtn');
  const loginBtnText = document.getElementById('loginBtnText');
  const devInfo = document.getElementById('devInfo');

  // Mostrar info de desarrollo si no estamos en producción
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    devInfo.classList.remove('d-none');
  }

  // Restaurar credenciales si está marcado "Recuerda mis datos"
  restoreCredentials();

  /**
   * Toggle mostrar/ocultar contraseña
   */
  togglePasswordBtn.addEventListener('click', function () {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);

    // Cambiar icono
    const icon = this.querySelector('i');
    icon.classList.toggle('bi-eye');
    icon.classList.toggle('bi-eye-slash');
  });

  /**
   * Manejar envío del formulario
   */
  loginForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    // Limpiar mensajes de error previos
    hideError();

    // Validación básica
    if (!email || !password) {
      showError('Por favor completa todos los campos');
      return;
    }

    if (!isValidEmail(email)) {
      showError('Por favor ingresa un email válido');
      return;
    }

    // Deshabilitar botón durante el login
    setLoginButtonLoading(true);

    try {
      // Realizar login
      const response = await authService.login(email, password);

      // Guardar credenciales si está marcado
      if (rememberMeCheckbox.checked) {
        saveCredentials(email);
      } else {
        clearCredentials();
      }

      // Redirigir al dashboard
      window.location.href = '/html/dashboard.html';
    } catch (error) {
      showError(error.message || 'Error al iniciar sesión. Intenta nuevamente.');
      setLoginButtonLoading(false);
    }
  });

  /**
   * Muestra mensaje de error
   */
  function showError(message) {
    errorMessage.textContent = message;
    errorAlert.classList.remove('d-none');
  }

  /**
   * Oculta mensaje de error
   */
  function hideError() {
    errorAlert.classList.add('d-none');
    errorMessage.textContent = '';
  }

  /**
   * Habilita/Deshabilita el botón de login
   */
  function setLoginButtonLoading(isLoading) {
    loginBtn.disabled = isLoading;
    if (isLoading) {
      loginBtnText.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Iniciando sesión...';
    } else {
      loginBtnText.innerHTML = 'Iniciar Sesión';
    }
  }

  /**
   * Valida formato de email
   */
  function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  /**
   * Guarda las credenciales en localStorage
   */
  function saveCredentials(email) {
    localStorage.setItem('remembered_email', email);
    localStorage.setItem('remember_me', 'true');
  }

  /**
   * Restaura las credenciales guardadas
   */
  function restoreCredentials() {
    const rememberedEmail = localStorage.getItem('remembered_email');
    const rememberMe = localStorage.getItem('remember_me') === 'true';

    if (rememberMe && rememberedEmail) {
      emailInput.value = rememberedEmail;
      rememberMeCheckbox.checked = true;
      passwordInput.focus();
    }
  }

  /**
   * Limpia las credenciales guardadas
   */
  function clearCredentials() {
    localStorage.removeItem('remembered_email');
    localStorage.removeItem('remember_me');
  }

  /**
   * Permitir Enter para enviar formulario
   */
  passwordInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      loginForm.dispatchEvent(new Event('submit'));
    }
  });

  // Si ya estaba autenticado, redirigir al dashboard
  if (authService.isAuthenticated() && authService.isTokenValid()) {
    window.location.href = '/html/dashboard.html';
  }
});
