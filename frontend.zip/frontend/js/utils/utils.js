/**
 * utils.js
 * Funciones utilitarias compartidas para el frontend
 * Incluye: Formateo de datos, validaciones, helpers comunes
 */

/**
 * Formatea una fecha en formato legible
 * @param {Date|string} date - Fecha a formatear
 * @param {string} locale - Idioma (ej: 'es-ES', 'en-US')
 * @returns {string} - Fecha formateada
 */
function formatDate(date, locale = 'es-ES') {
  if (!date) return '-';
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString(locale);
}

/**
 * Formatea hora en formato legible
 * @param {Date|string} date - Fecha/hora a formatear
 * @param {string} locale - Idioma (ej: 'es-ES')
 * @returns {string} - Hora formateada
 */
function formatTime(date, locale = 'es-ES') {
  if (!date) return '-';
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleTimeString(locale, {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

/**
 * Formatea fecha y hora completa
 * @param {Date|string} date - Fecha/hora a formatear
 * @param {string} locale - Idioma
 * @returns {string} - Fecha y hora formateadas
 */
function formatDateTime(date, locale = 'es-ES') {
  if (!date) return '-';
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleString(locale);
}

/**
 * Formatea un número como moneda
 * @param {number} amount - Cantidad a formatear
 * @param {string} currency - Código de moneda (ej: 'USD', 'COP')
 * @param {string} locale - Idioma
 * @returns {string} - Cantidad formateada
 */
function formatCurrency(amount, currency = 'COP', locale = 'es-CO') {
  if (amount === null || amount === undefined) return '$0.00';
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency
  }).format(amount);
}

/**
 * Formatea un número con separadores
 * @param {number} number - Número a formatear
 * @param {number} decimals - Decimales a mostrar
 * @returns {string} - Número formateado
 */
function formatNumber(number, decimals = 2) {
  if (number === null || number === undefined) return '0.00';
  return parseFloat(number).toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * Valida un email
 * @param {string} email - Email a validar
 * @returns {boolean} - True si es válido
 */
function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

/**
 * Valida una cédula/documento de identidad
 * @param {string} cedula - Documento a validar
 * @returns {boolean} - True si es válido
 */
function isValidCedula(cedula) {
  // Validación básica: números y guiones
  const re = /^[0-9]{5,20}(?:-[0-9]{1,4})?$/;
  return re.test(cedula);
}

/**
 * Valida un teléfono
 * @param {string} phone - Teléfono a validar
 * @returns {boolean} - True si es válido
 */
function isValidPhone(phone) {
  // Validación básica: números, espacios, guiones, paréntesis, +
  const re = /^[0-9+\s\-()]{7,20}$/;
  return re.test(phone);
}

/**
 * Valida una contraseña (mínimo 8 caracteres, mayúsculas, números)
 * @param {string} password - Contraseña a validar
 * @returns {boolean} - True si es válida
 */
function isValidPassword(password) {
  // Mínimo 8 caracteres, al menos una mayúscula y un número
  const re = /^(?=.*[A-Z])(?=.*\d).{8,}$/;
  return re.test(password);
}

/**
 * Genera un UUID v4
 * @returns {string} - UUID generado
 */
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Trunca un string a una longitud máxima
 * @param {string} text - Texto a truncar
 * @param {number} maxLength - Longitud máxima
 * @param {string} suffix - Sufijo (ej: '...')
 * @returns {string} - Texto truncado
 */
function truncateString(text, maxLength = 50, suffix = '...') {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength - suffix.length) + suffix;
}

/**
 * Capitaliza la primera letra
 * @param {string} text - Texto a capitalizar
 * @returns {string} - Texto capitalizado
 */
function capitalize(text) {
  if (!text) return '';
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

/**
 * Capitaliza todas las palabras
 * @param {string} text - Texto a capitalizar
 * @returns {string} - Texto capitalizado
 */
function capitalizeWords(text) {
  if (!text) return '';
  return text.replace(/\b\w/g, (char) => char.toUpperCase());
}

/**
 * Calcula la edad a partir de una fecha de nacimiento
 * @param {Date|string} birthDate - Fecha de nacimiento
 * @returns {number} - Edad
 */
function calculateAge(birthDate) {
  const today = new Date();
  let age = today.getFullYear() - new Date(birthDate).getFullYear();
  const monthDiff = today.getMonth() - new Date(birthDate).getMonth();
  if (
    monthDiff < 0 ||
    (monthDiff === 0 && today.getDate() < new Date(birthDate).getDate())
  ) {
    age--;
  }
  return age;
}

/**
 * Espera un tiempo determinado
 * @param {number} ms - Milisegundos a esperar
 * @returns {Promise} - Promesa que se resuelve después del tiempo
 */
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Copia texto al portapapeles
 * @param {string} text - Texto a copiar
 * @returns {Promise<boolean>} - True si se copió exitosamente
 */
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error('Error copiando al portapapeles:', error);
    return false;
  }
}

/**
 * Obtiene un parámetro de la URL
 * @param {string} paramName - Nombre del parámetro
 * @returns {string|null} - Valor del parámetro
 */
function getUrlParameter(paramName) {
  const params = new URLSearchParams(window.location.search);
  return params.get(paramName);
}

/**
 * Convierte un objeto a parámetros de URL
 * @param {Object} params - Objeto con parámetros
 * @returns {string} - String de parámetros
 */
function objectToQueryString(params) {
  return Object.keys(params)
    .map((key) => encodeURIComponent(key) + '=' + encodeURIComponent(params[key]))
    .join('&');
}

/**
 * Muestra una notificación tipo toast (si Bootstrap está disponible)
 * @param {string} message - Mensaje a mostrar
 * @param {string} type - Tipo de alerta (success, danger, warning, info)
 * @param {number} duration - Duración en ms (0 = manual)
 */
function showToast(message, type = 'info', duration = 3000) {
  // Crear elemento toast
  const toastHtml = `
    <div class="toast align-items-center text-white bg-${type === 'error' ? 'danger' : type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body">
          ${message}
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  `;

  // Crear contenedor si no existe
  let toastContainer = document.getElementById('toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
    `;
    document.body.appendChild(toastContainer);
  }

  // Agregar toast
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = toastHtml;
  const toastElement = tempDiv.firstElementChild;
  toastContainer.appendChild(toastElement);

  // Mostrar toast
  const toast = new bootstrap.Toast(toastElement);
  toast.show();

  // Remover elemento después
  toastElement.addEventListener('hidden.bs.toast', () => {
    toastElement.remove();
  });
}

/**
 * Muestra un modal de confirmación
 * @param {string} title - Título del modal
 * @param {string} message - Mensaje
 * @returns {Promise<boolean>} - True si confirma, False si cancela
 */
function showConfirmModal(title = 'Confirmación', message = '¿Estás seguro?') {
  return new Promise((resolve) => {
    const html = `
      <div class="modal fade" id="confirmModal" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">${title}</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              ${message}
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
              <button type="button" class="btn btn-primary" id="confirmBtn">Confirmar</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    const modalElement = tempDiv.firstElementChild;
    document.body.appendChild(modalElement);

    const modal = new bootstrap.Modal(modalElement);
    const confirmBtn = modalElement.querySelector('#confirmBtn');

    confirmBtn.addEventListener('click', () => {
      modal.hide();
      modalElement.remove();
      resolve(true);
    });

    modalElement.addEventListener('hidden.bs.modal', () => {
      modalElement.remove();
      resolve(false);
    });

    modal.show();
  });
}
